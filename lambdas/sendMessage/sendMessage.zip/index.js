import { db } from "../shared/firebaseAdmin.js";
import {
  DynamoDBClient,
  ScanCommand,
  DeleteItemCommand
} from "@aws-sdk/client-dynamodb";
import {
  ApiGatewayManagementApiClient,
  PostToConnectionCommand
} from "@aws-sdk/client-apigatewaymanagementapi";

const ddb = new DynamoDBClient({});

export const handler = async (event) => {
  const { domainName, stage, connectionId: senderConnId } = event.requestContext;
  const api = new ApiGatewayManagementApiClient({
    endpoint: `https://${domainName}/${stage}`
  });

  const body = JSON.parse(event.body || "{}");
  const text = body.data || body.message || "";

  /* ─── Lookup sender userId from Firestore mapping ─── */
  const senderSnap = await db
    .collection("connections")
    .where("connectionId", "==", senderConnId)
    .limit(1)
    .get();

  const senderUserId = senderSnap.empty ? "unknown" : senderSnap.docs[0].id;
  const senderNick   = senderSnap.empty ? "Anonymous" : (senderSnap.docs[0].data().nickname || "Anonymous");

  /* ─── Persist message in Firestore ─── */
  const msgDoc = {
    senderId   : senderUserId,
    senderNick,
    text,
    timestamp  : Date.now()
  };
  await db.collection("messages").add(msgDoc);

  /* ─── Broadcast to every other active connection ─── */
  const { Items } = await ddb.send(new ScanCommand({
    TableName: process.env.CONNECTIONS_TABLE,
    ProjectionExpression: "connectionId"
  }));

  const tasks = Items.map(async (it) => {
    const targetId = it.connectionId.S;
    if (targetId === senderConnId) return; // skip echo to sender

    try {
      await api.send(new PostToConnectionCommand({
        ConnectionId: targetId,
        Data: JSON.stringify({
          from   : senderNick,
          text,
          ts     : msgDoc.timestamp
        })
      }));
    } catch (err) {
      if (err.$metadata?.httpStatusCode === 410) {
        // stale → purge from DynamoDB & Firestore
        await ddb.send(new DeleteItemCommand({
          TableName: process.env.CONNECTIONS_TABLE,
          Key: { connectionId: { S: targetId } }
        }));
        const q = await db.collection("connections")
                          .where("connectionId","==",targetId).get();
        q.forEach(doc => doc.ref.delete());
      } else {
        console.error("PostToConnection failed", err);
      }
    }
  });

  await Promise.all(tasks);
  return { statusCode: 200, body: "Sent & stored" };
};
