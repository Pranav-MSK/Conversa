export const handler = async () => ({
  statusCode: 400,
  body: "Unrecognised route"
});
